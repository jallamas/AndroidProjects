package org.jallamas.examenrecyclerview;

interface IContactoListener {
    void onContactoClick(Contacto contacto);
}
