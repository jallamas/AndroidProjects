package org.jallamas.examenrecyclerview;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

class DetalleContactoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_contacto);
    }
}
