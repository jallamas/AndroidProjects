package com.example.themoviedbseries.common;

public class Constantes {

    public static final String URL_BASE="https://api.themoviedb.org/3/";
    public static final String API_KEY="7405b969ba368f29d1cbb4a632648138";
    public static final String URL_IMAGES="https://image.tmdb.org/t/p/w500";
}
