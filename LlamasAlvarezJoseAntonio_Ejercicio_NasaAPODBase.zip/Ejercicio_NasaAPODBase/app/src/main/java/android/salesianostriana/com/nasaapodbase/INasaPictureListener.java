package android.salesianostriana.com.nasaapodbase;

import android.salesianostriana.com.api.NasaPicture;

public interface INasaPictureListener {
    public void onNasaPictureClick(NasaPicture r);
}
