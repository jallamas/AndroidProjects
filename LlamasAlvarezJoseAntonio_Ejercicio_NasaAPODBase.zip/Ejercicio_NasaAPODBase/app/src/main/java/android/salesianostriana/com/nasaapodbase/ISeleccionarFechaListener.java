package android.salesianostriana.com.nasaapodbase;

interface ISeleccionarFechaListener {
    void onFechaSeleccionada(int year, int month, int day);
}
