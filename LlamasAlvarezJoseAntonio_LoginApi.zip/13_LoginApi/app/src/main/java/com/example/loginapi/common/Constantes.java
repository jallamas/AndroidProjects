package com.example.loginapi.common;

public class Constantes {
    public static final String API_BASE_URL = "http://10.0.2.2:3000/api/";
}
